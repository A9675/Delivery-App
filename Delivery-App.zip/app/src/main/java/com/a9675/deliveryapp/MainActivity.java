package com.a9675.deliveryapp;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    LinearLayout root, orderBox;
    TextView title, status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showLogin();
    }

    TextView text(String s, int size) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(size);
        v.setTextColor(Color.BLACK);
        v.setPadding(20, 20, 20, 20);
        return v;
    }

    Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        return b;
    }

    void base() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(40, 70, 40, 40);
        scroll.addView(root);
        setContentView(scroll);
    }

    void showLogin() {
        base();
        title = text("Delivery App", 30);
        title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        EditText phone = new EditText(this);
        phone.setHint("Mobile number");
        phone.setInputType(2);
        root.addView(phone);

        EditText password = new EditText(this);
        password.setHint("Password");
        password.setInputType(129);
        root.addView(password);

        Button login = button("LOGIN");
        root.addView(login);
        login.setOnClickListener(v -> showHome());
    }

    void showHome() {
        base();
        root.addView(text("Delivery Partner Dashboard", 27));
        root.addView(text("Welcome! You have 1 new delivery order.", 18));

        orderBox = new LinearLayout(this);
        orderBox.setOrientation(LinearLayout.VERTICAL);
        orderBox.setPadding(20,20,20,20);
        orderBox.addView(text("NEW ORDER #1001", 22));
        orderBox.addView(text("Pickup: City Restaurant\nDrop: Customer Address\nDistance: 3.2 km\nPayment: ₹250 - Cash on Delivery", 17));

        Button accept = button("ACCEPT ORDER");
        Button reject = button("REJECT ORDER");
        orderBox.addView(accept);
        orderBox.addView(reject);
        root.addView(orderBox);

        status = text("", 18);
        root.addView(status);

        accept.setOnClickListener(v -> showAccepted());
        reject.setOnClickListener(v -> {
            orderBox.setVisibility(View.GONE);
            status.setText("Order rejected.");
        });
    }

    void showAccepted() {
        orderBox.removeAllViews();
        orderBox.addView(text("ORDER #1001", 22));
        orderBox.addView(text("Status: Accepted\nPickup: City Restaurant\nDrop: Customer Address", 18));
        Button pickup = button("ORDER PICKED UP");
        orderBox.addView(pickup);
        pickup.setOnClickListener(v -> showOutForDelivery());
    }

    void showOutForDelivery() {
        orderBox.removeAllViews();
        orderBox.addView(text("ORDER #1001\nStatus: Out for delivery", 20));
        Button delivered = button("MARK AS DELIVERED");
        orderBox.addView(delivered);
        delivered.setOnClickListener(v -> {
            orderBox.removeAllViews();
            orderBox.addView(text("✓ Delivery Completed\nOrder #1001 delivered successfully.", 22));
        });
    }
}
