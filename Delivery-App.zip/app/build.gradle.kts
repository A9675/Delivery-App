plugins {
    id("com.android.application")
}

android {
    namespace = "com.a9675.deliveryapp"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.a9675.deliveryapp"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}

dependencies {
}
