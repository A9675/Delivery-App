# Delivery App

Basic Android delivery partner demo app.

Features:
- Login screen
- Delivery dashboard
- New order
- Order details
- Accept / Reject
- Picked up status
- Delivered status

APK is automatically built using GitHub Actions.
